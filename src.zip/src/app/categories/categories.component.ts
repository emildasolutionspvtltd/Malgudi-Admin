import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { AngularFireDatabase } from '@angular/fire/database';
import { SnackbarService } from '../snackbar.service';
import { AngularFireStorage } from '@angular/fire/storage';

export interface PeriodicElement {
  serial_no: string;
  category_n:string;
  name:string;
 
}
@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.scss']
})
export class CategoriesComponent implements OnInit {
  Category
  Progress
  DownloadUrl
  addCat = new FormGroup({
    categoryName : new FormControl('',Validators.required),
    categoryDescription:  new FormControl('',Validators.required),
    file : new FormControl('',Validators.required),
  });

  constructor(private af:AngularFireDatabase, private storage : AngularFireStorage,private snack :SnackbarService) { }

  ngOnInit() {
    this.af.list('/category/').valueChanges().subscribe(res =>{
      this.Category=res
      //console.log(this.Category)
      }
      
        )
  }

  displayedColumns: string[] = ['serial_number','category_n','name'];
  dataSource = this.Category;

  upload(event){

    const UId = this.af.createPushId()
    const file = event.target.files[0];
    const filePath = `category/${UId}`;
    const ref = this.storage.ref(filePath);
    const task = ref.put(file);

    task.percentageChanges().subscribe(res=>{
      console.log(res)
      this.Progress=res
      
})
task.then(
  x=>{
   ref.getDownloadURL().subscribe(res=>{
     console.log(res)
    this.DownloadUrl=res
   })
   
  }
)


}


  addCategory(){
if (this.addCat.valid){

    this.af.list('/category').push(this.addCat.value).then(x=>{
this.addCat.reset()
this.snack.openSnackBar("Category added SuccessFully  👍 ","Ok")
      





    }).catch(err=>{
      this.snack.openSnackBar(err,"Ok")
    })

}else{


this.snack.openSnackBar("Please fill a valid Input","Ok")
}
    

}
}
