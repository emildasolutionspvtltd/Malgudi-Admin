import { Component, OnInit } from '@angular/core';
import { AngularFireDatabase } from '@angular/fire/database';


export interface PeriodicElement {
  date: string;
  order_id:string;
  customer_id: string;
  status: string;
}


@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.scss']
})
export class OrdersComponent implements OnInit {
order
  constructor(private db:AngularFireDatabase,private storage : AngularFireDatabase) { }

  ngOnInit() {

    this.db.list('/orders/').valueChanges().subscribe(res =>{
    this.order=res
    //console.log(this.order)
    }
    
      )

  }
  
  displayedColumns: string[] = ['date','order_id','customer_id','status' ];
  dataSource = this.order;
}
