import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, ControlContainer } from '@angular/forms';
import { AngularFireDatabase } from '@angular/fire/database';
export interface PeriodicElement {
  serial_no: string;
  suppliername:string;
  phone: string;
  Email: string;
}
@Component({
  selector: 'app-supplier',
  templateUrl: './supplier.component.html',
  styleUrls: ['./supplier.component.scss']
})
export class SupplierComponent implements OnInit {
 supplier
  constructor(private fb: FormBuilder,private db: AngularFireDatabase) { 

  }
  addSupplier = new FormGroup({
    suppliername: new FormControl('',Validators.required),
    compname:new FormControl('',Validators.required),
    phone: new FormControl('',Validators.required),
    Mobile: new FormControl('',Validators.required),
    Fax : new FormControl('',Validators.required),
    Email : new FormControl('',Validators.required),
    Website : new FormControl('',Validators.required),

  })

  ngOnInit() {

    this.db.list('/supplier/').valueChanges().subscribe(res =>{
    this.supplier=res
    //console.log(this.order)
    }
    
      )

  }
  displayedColumns: string[] = ['serial_number','suppliername','phone','Email' ];
  dataSource = this.supplier;


submit(){
  if(this.addSupplier.valid)
{

  console.log(this.addSupplier.value)
  this.db.list('/suppliers').push(this.addSupplier.value).then(x=>{
    console.log("success")
  })
}
else{
  console.log("validate properly")
}
}
}


