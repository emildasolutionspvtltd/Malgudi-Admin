export const environment = {
  production: true,
  apiKey: "AIzaSyDElyoNjSWw-n69a6suXLug5eWM9hGDFl4",
  authDomain: "netherlands-54cf0.firebaseapp.com",
  databaseURL: "https://netherlands-54cf0.firebaseio.com",
  projectId: "netherlands-54cf0",
  storageBucket: "netherlands-54cf0.appspot.com",
  messagingSenderId: "483922012527",
  appId: "1:483922012527:web:46c0524f7f687c504c609a",
};
